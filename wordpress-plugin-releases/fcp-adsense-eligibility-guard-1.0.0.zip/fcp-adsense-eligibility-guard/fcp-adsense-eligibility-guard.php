<?php
/**
 * Plugin Name: FlooringCostPro AdSense Eligibility Guard
 * Description: Keeps the existing AdSense verification script on the homepage and long-form published content, but removes that script from legal pages, archives, searches, 404s and short content.
 * Version: 1.0.0
 * Author: FlooringCostPro Team
 * License: GPL-2.0-or-later
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Text Domain: fcp-adsense-eligibility-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Count the approximate editorial words stored in one published post/page.
 * Never render or change content or execute shortcodes merely to count words.
 */
function fcp_aeg_word_count( $post ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return 0;
    }
    $content = (string) $post->post_content;
    $content = preg_replace( '~<(?:script|style)\b[^>]*>[\s\S]*?</(?:script|style)\s*>~i', ' ', $content );
    $content = preg_replace( '~<!--([\s\S]*?)-->~', ' ', $content );
    $content = strip_shortcodes( $content );
    $content = wp_strip_all_tags( $content, true );
    $content = html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
    if ( ! is_string( $content ) || '' === trim( $content ) ) {
        return 0;
    }
    $matches = array();
    $result  = preg_match_all( '~[\p{L}\p{N}]+(?:[\x27\x{2019}-][\p{L}\p{N}]+)*~u', $content, $matches );
    return false === $result ? 0 : (int) $result;
}

/**
 * Approved page TYPES for an existing pre-approval verification script.
 * The front page is always eligible. Everything else must be a published,
 * substantive article/guide/tool (at least 800 editorial words).
 */
function fcp_aeg_eligible_route() {
    if ( is_front_page() ) {
        return true;
    }
    if ( ! is_singular( array( 'post', 'page' ) ) ) {
        return false;
    }

    $post = get_queried_object();
    if ( ! ( $post instanceof WP_Post ) || 'publish' !== $post->post_status ) {
        return false;
    }

    // Always keep advertising scripts away from trust/policy and legacy policy URLs.
    $never = array(
        'about', 'about-us', 'contact', 'contact-us', 'privacy-policy',
        'terms', 'terms-of-use', 'disclaimer', 'advertiser-disclosure',
        'editorial-policy', 'editorial-teams', 'corrections-policy',
        'accuracy-and-data-policy', 'data-sources', 'who-is-for',
        'accessibility-statement', 'apply-and-eligibility-checker',
    );
    if ( in_array( $post->post_name, $never, true ) ) {
        return false;
    }
    return fcp_aeg_word_count( $post ) >= 800;
}

/**
 * Filter only the canonical Google ad bootstrap script (including its
 * protocol-relative and Cloudflare data-src forms). Do NOT touch Analytics,
 * Site Kit, Rank Math or any unrelated JS, canonical tags or article markup.
 */
function fcp_aeg_remove_ineligible_bootstrap( $html ) {
    if ( ! is_string( $html ) || false === stripos( $html, 'adsbygoogle.js' ) ) {
        return $html;
    }
    $pattern = '~<script\b(?=[^>]*\b(?:src|data-src|data-rocket-src)\s*=\s*[\x22\x27](?:https?:)?//pagead2\.googlesyndication\.com/pagead/js/adsbygoogle\.js(?:\?[^\x22\x27]*)?[\x22\x27])[^>]*>\s*</script\s*>~i';
    $output  = preg_replace( $pattern, '', $html );
    return is_string( $output ) ? $output : $html;
}

/**
 * The site's existing bootstrap is inserted ahead of wp_head() by the theme;
 * removing enqueued scripts alone cannot suppress that early literal tag.
 * At template_redirect WordPress has resolved the route and NO HTML has been
 * emitted, so this scoped output buffer safely removes only that one tag.
 */
function fcp_aeg_start_output_guard() {
    if ( is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_trackback() ) {
        return;
    }
    if ( fcp_aeg_eligible_route() ) {
        return;
    }
    ob_start( 'fcp_aeg_remove_ineligible_bootstrap' );
}
add_action( 'template_redirect', 'fcp_aeg_start_output_guard', 0 );
