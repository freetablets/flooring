=== FlooringCostPro AdSense Eligibility Guard ===
Contributors: flooringcostpro
Tags: adsense, script, review, filtering
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Restricts an existing hard-coded adsbygoogle.js verification bootstrap to the homepage and published posts/pages with 800+ editorial words, excluding legal pages, archived policy URLs, archive types, searches and 404s.

This plugin does not insert new AdSense IDs, ads, ad units or third-party scripts. It leaves the existing verified AdSense snippet unmodified on eligible content. Disable this plugin to revert. Flush WordPress/LiteSpeed cache after activation.

Security: No settings page, database modifications, remote calls, cookies, filesystem writes or credential handling.

Version 1.0.1: On excluded routes also strips the theme AdSense HTML comment and only the Site Kit AdSense-platform metadata/comments. Keeps Site Kit analytics untouched.
