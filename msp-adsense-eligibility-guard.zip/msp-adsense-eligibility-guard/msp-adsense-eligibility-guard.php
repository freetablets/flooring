<?php
/**
 * Plugin Name: MSP AdSense Eligibility Guard
 * Description: Pre-approval AdSense head-tag scope guard for MedicareSavingPrograms.com.
 * Version: 1.0.0
 * Requires PHP: 7.4
 * Author: MSP Editorial
 */
if (!defined('ABSPATH')) { exit; }

final class MSP_Adsense_Eligibility_Guard {
    private const OPTION = 'msp_aeg_publisher_id';

    public static function init() : void {
        add_action('admin_init', [__CLASS__, 'register']);
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('wp_head', [__CLASS__, 'emit'], 1);
        add_filter('script_loader_tag', [__CLASS__, 'filter_script_tag'], 10, 3);
        add_filter('wp_headers', [__CLASS__, 'ads_txt_no_cache']);
        add_action('template_redirect', [__CLASS__, 'ads_txt_404'], 0);
    }
    public static function register() : void {
        register_setting('msp_aeg', self::OPTION, ['type'=>'string','sanitize_callback'=>[__CLASS__,'sanitize'],'default'=>'']);
    }
    public static function sanitize($value) : string {
        $id = trim((string)$value);
        return preg_match('/^ca-pub-[0-9]{12,20}$/', $id) ? $id : '';
    }
    public static function menu() : void {
        add_options_page('MSP AdSense Eligibility Guard', 'MSP AdSense Guard', 'manage_options', 'msp-adsense-guard', [__CLASS__,'settings']);
    }
    public static function settings() : void {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>MSP AdSense Eligibility Guard</h1><p>Set the real publisher ID. Only the homepage and published 800+ word standard posts receive one official AdSense head script. All other routes are excluded.</p><form method="post" action="options.php">';
        settings_fields('msp_aeg');
        printf('<p><label for="msp_aeg_id">Publisher ID (ca-pub-…)</label><br><input id="msp_aeg_id" class="regular-text" type="text" name="%s" value="%s" placeholder="ca-pub-1234567890123456" autocomplete="off"></p>', esc_attr(self::OPTION), esc_attr(get_option(self::OPTION,'')));
        submit_button(); echo '</form><p><strong>Important:</strong> Remove other AdSense injection sources to prevent duplicate scripts. This plugin does not change article content, SEO metadata, menus, or income tables.</p></div>';
    }
    private static function eligible() : bool {
        if (is_admin() || is_feed() || is_404() || is_search() || is_archive() || is_home() || is_preview() || is_embed() || is_robots()) { return false; }
        if (is_front_page()) { return true; }
        if (!is_singular('post')) { return false; }
        $post = get_queried_object();
        if (!($post instanceof WP_Post) || $post->post_status !== 'publish') { return false; }
        $text = strip_shortcodes($post->post_content);
        $text = wp_strip_all_tags($text, true);
        $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
        return is_array($words) && count($words) >= 800;
    }
    public static function emit() : void {
        if (!self::eligible()) { return; }
        $id = self::sanitize(get_option(self::OPTION,''));
        if ($id === '') { return; }
        echo "\n<!-- MSP AdSense Eligibility Guard -->\n";
        printf('<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=%s" crossorigin="anonymous"></script>' . "\n", esc_attr($id));
    }
    public static function filter_script_tag(string $tag, string $handle, string $src) : string {
        if (strpos($src, 'pagead2.googlesyndication.com/pagead/js/adsbygoogle.js') !== false && !self::eligible()) { return ''; }
        return $tag;
    }
    public static function ads_txt_no_cache(array $headers) : array {
        if (isset($_SERVER['REQUEST_URI']) && parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) === '/ads.txt') {
            $headers['Cache-Control'] = 'no-store, no-cache, must-revalidate';
        }
        return $headers;
    }
    public static function ads_txt_404() : void {
        if (!isset($_SERVER['REQUEST_URI']) || parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) !== '/ads.txt') { return; }
        // Only handles WordPress's dynamic route; a physical file or CDN rule must be removed separately.
        global $wp_query;
        if ($wp_query instanceof WP_Query) { $wp_query->set_404(); }
        status_header(404); nocache_headers();
        include get_404_template(); exit;
    }
}
MSP_Adsense_Eligibility_Guard::init();
