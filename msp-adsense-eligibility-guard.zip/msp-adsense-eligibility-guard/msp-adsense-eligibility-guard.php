<?php
/**
 * Plugin Name: MSP AdSense Eligibility Guard
 * Description: Pre-approval AdSense head-tag scope guard for MedicareSavingPrograms.com.
 * Version: 1.3.0
 * Requires PHP: 7.4
 * Author: MSP Editorial
 */
if (!defined('ABSPATH')) { exit; }

final class MSP_Adsense_Eligibility_Guard {
    private const OPTION = 'msp_aeg_publisher_id';

    public static function init() : void {
        add_action('admin_init', [__CLASS__, 'register']);
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('wp_head', [__CLASS__, 'emit'], 1);
        add_filter('script_loader_tag', [__CLASS__, 'filter_script_tag'], 10, 3);
        add_filter('wp_headers', [__CLASS__, 'ads_txt_no_cache']);
        add_action('template_redirect', [__CLASS__, 'ads_txt_404'], 0);
        add_action('template_redirect', [__CLASS__, 'start_response_guard'], 5);
        add_filter('the_content', [__CLASS__, 'sanitize_educational_pages'], 999);
    }
    public static function register() : void {
        register_setting('msp_aeg', self::OPTION, ['type'=>'string','sanitize_callback'=>[__CLASS__,'sanitize'],'default'=>'']);
    }
    public static function sanitize($value) : string {
        $id = trim((string)$value);
        return preg_match('/^ca-pub-[0-9]{12,20}$/', $id) ? $id : '';
    }
    public static function menu() : void {
        add_options_page('MSP AdSense Eligibility Guard', 'MSP AdSense Guard', 'manage_options', 'msp-adsense-guard', [__CLASS__,'settings']);
    }
    public static function settings() : void {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>MSP AdSense Eligibility Guard</h1><p>Set the real publisher ID. Only the homepage and published 800+ word standard posts receive one official AdSense head script. All other routes are excluded.</p><form method="post" action="options.php">';
        settings_fields('msp_aeg');
        printf('<p><label for="msp_aeg_id">Publisher ID (ca-pub-…)</label><br><input id="msp_aeg_id" class="regular-text" type="text" name="%s" value="%s" placeholder="ca-pub-1234567890123456" autocomplete="off"></p>', esc_attr(self::OPTION), esc_attr(get_option(self::OPTION,'')));
        submit_button(); echo '</form><p><strong>Important:</strong> Remove other AdSense injection sources to prevent duplicate scripts. This plugin does not change article content, SEO metadata, menus, or income tables.</p></div>';
    }
    private static function eligible() : bool {
        if (is_admin() || is_feed() || is_404() || is_search() || is_archive() || is_home() || is_preview() || is_embed() || is_robots()) { return false; }
        if (is_front_page()) { return true; }
        if (!is_singular('post')) { return false; }
        $post = get_queried_object();
        if (!($post instanceof WP_Post) || $post->post_status !== 'publish') { return false; }
        $text = strip_shortcodes($post->post_content);
        $text = wp_strip_all_tags($text, true);
        $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
        return is_array($words) && count($words) >= 800;
    }
    public static function emit() : void {
        if (!self::eligible()) { return; }
        $id = self::sanitize(get_option(self::OPTION,''));
        if ($id === '') { return; }
        echo "\n<!-- MSP AdSense Eligibility Guard -->\n";
        printf('<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=%s" crossorigin="anonymous"></script>' . "\n", esc_attr($id));
    }
    public static function filter_script_tag(string $tag, string $handle, string $src) : string {
        if (strpos($src, 'pagead2.googlesyndication.com/pagead/js/adsbygoogle.js') !== false && !self::eligible()) { return ''; }
        return $tag;
    }
    public static function sanitize_educational_pages($content) {
        if (!is_string($content)) { return $content; }
        if (is_page('apply-now') && strpos($content, 'msp-wizard-wrap') !== false) {
            // Shortcoder expands before this filter; remove only the exact standalone 8-step wizard,
            // preserving the complete written educational article, its links and JSON-LD schema.
            $content = preg_replace('~<section\s+class="msp-wizard-wrap"[^>]*>.*?</section>~is', '', $content, 1);
            $content = preg_replace('~<script>\s*\(function\(\)\{\s*"use strict";\s*const\s+totalSteps\s*=\s*8;.*?</script>~is', '', $content, 1);
            $content = str_replace('Use this private screener to estimate which Medicare Savings Program bracket may fit you, then continue to your state application guide or state resources page.', 'Review the written 2026 Medicare Savings Program guide below, then use your state Medicaid agency for an official eligibility decision.', $content);
            $content = str_replace('Start with the screener above', 'Start with the educational steps below', $content);
            $content = str_replace('Use the private screener at the top of this page. After your state is selected, the button will send visitors to the live state guide if you have published it, or to the state resources page if that guide is not active yet.', 'Review the application steps above, then use the State MSP Resources directory to find official state application guidance.', $content);
            $content = str_replace('href="#msp-wizard"', 'href="/state-resources/"', $content);
            $content = str_replace('Check My MSP Route', 'Review State MSP Resources', $content);
            $content = str_replace('Start the Screener', 'Find Official State Guidance', $content);
        }
        if (is_front_page() && strpos($content, 'msp-page msp-home') !== false) {
            // Delete the fake backdated published line from the rendered homepage DOM only.
            $content = preg_replace('~<span><span\s+class="msp-icon-dot"></span>Published\s*<time\s+datetime="2021-03-13">.*?</time></span>~is', '', $content, 1);
            $content = str_replace('datetime="2026-08-13">August 13, 2026', 'datetime="2026-10-22">October 22, 2026', $content);
            $content = str_replace('href="#states"', 'href="/state-resources/"', $content);
            $content = str_replace('href="#limits"', 'href="/medicare-savings-program-income-limits/"', $content);
        }
        return $content;
    }
    /**
     * Normalize the final public HTML after Kadence and legacy publisher integrations
     * render. This avoids rewriting stored medical/eligibility guides or SEO metadata.
     */
    public static function start_response_guard() : void {
        if (is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_preview()) { return; }
        ob_start([__CLASS__, 'clean_output_html']);
    }
    public static function clean_output_html(string $html) : string {
        if (stripos($html, '<head') === false) { return $html; }

        // Remove legacy unconditional head tags, and the guard's earlier tag.
        // Reinsert exactly one only when this requested page qualifies.
        $html = preg_replace(
            '~<script\b[^>]*\bsrc\s*=\s*["\x27]https?://pagead2\.googlesyndication\.com/pagead/js/adsbygoogle\.js[^"\x27]*["\x27][^>]*>\s*</script>\s*~i',
            '',
            $html
        );
        $html = str_replace('<!-- MSP AdSense Eligibility Guard -->', '', $html);
        if (self::eligible()) {
            $id = self::sanitize(get_option(self::OPTION, ''));
            if ($id !== '') {
                $script = "\n<!-- MSP AdSense Eligibility Guard: one eligible head tag -->\n"
                    . '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='
                    . esc_attr($id) . '" crossorigin="anonymous"></script>' . "\n";
                $html = preg_replace('~(<head\b[^>]*>)~i', '$1' . $script, $html, 1);
            }
        }

        // The obsolete publisher strip is produced by a legacy sitewide
        // integration, not by the Contact page. Never fabricate corporate info.
        $html = preg_replace(
            '~<div\s+class="msp-publisher-inner">\s*<p><strong>Publisher:</strong>\s*MSP Media Group LLC.*?</div>~is',
            '<div class="msp-publisher-inner"><p>MedicareSavingPrograms.com is an independent educational publication. It is not a government benefits office.</p><p><strong>Editorial email:</strong> admin@medicaresavingprograms.com</p><p><strong>Corrections:</strong> corrections@medicaresavingprograms.com</p></div>',
            $html,
            1
        );
        // Kadence emits six unique related cards by default. Keep exactly five
        // without duplicating carousel elements or editing any article body.
        if (is_singular('post')) {
            $marker = 'class="splide__list kadence-posts-list';
            $at = strpos($html, $marker);
            if ($at !== false) {
                $open = strripos(substr($html, 0, $at), '<ul');
                $end = strpos($html, '</ul>', $at);
                if ($open !== false && $end !== false) {
                    $block = substr($html, $open, $end + 5 - $open);
                    preg_match_all('~<li\s+class="entry-list-item carousel-item splide__slide"[^>]*>.*?</li>~is', $block, $cards);
                    if (count($cards[0]) > 5) {
                        foreach (array_slice($cards[0], 5) as $extra) {
                            $block = str_replace($extra, '', $block);
                        }
                        $html = substr_replace($html, $block, $open, $end + 5 - $open);
                    }
                }
            }
        }

        // Final header/footer remediation: only site-owned markup and internal URLs.
        $html = self::normalize_editorial_navigation($html);
        return $html;
    }

    private static function normalize_editorial_navigation(string $html) : string {
        if (strpos($html, 'msp-master-header') === false) { return $html; }
        $nav_items = [
            '/category/msp-program-guides/' => 'MSP Program Guides',
            '/category/eligibility-income-rules/' => 'Eligibility &amp; Income Rules',
            '/category/part-b-qmb-benefits/' => 'Part B &amp; QMB Benefits',
            '/category/state-msp-guides/' => 'State MSP Guides',
        ];
        $desktop = '';
        $mobile = '';
        foreach ($nav_items as $url => $label) {
            $desktop .= '<a href="' . esc_url($url) . '" class="msp-nav-link">' . $label . '</a>';
            $mobile .= '<a href="' . esc_url($url) . '" class="msp-drawer-link">' . $label . '</a>';
        }
        $html = preg_replace('~(<div\s+class="msp-nav-links">).*?(</div>)~is', '$1' . $desktop . '$2', $html, 1);
        $html = preg_replace('~(<nav\s+class="msp-drawer-links"[^>]*>).*?(</nav>)~is', '$1' . $mobile . '$2', $html, 1);

        $legal_items = [
            '/about-us/' => 'About Us',
            '/contact-us/' => 'Contact Us',
            '/privacy-policy/' => 'Privacy Policy',
            '/terms-of-use/' => 'Terms &amp; Disclaimer',
        ];
        $legal = '';
        foreach ($legal_items as $url => $label) {
            $legal .= '<a href="' . esc_url($url) . '" rel="nofollow">' . $label . '</a>';
        }
        if (strpos($html, 'msp-legal-utility') === false) {
            $utility = '<div class="msp-legal-utility"><nav aria-label="Site information" class="msp-legal-utility-links">' . $legal . '</nav></div>';
            $html = str_replace('<!-- Main navigation -->', $utility . "\n<!-- Main navigation -->", $html);
            $html = preg_replace('~(<div\s+class="msp-publisher-inner">.*?)(</div>)~is', '$1' . '<nav class="msp-legal-footer" aria-label="Legal information">' . $legal . '</nav>' . '$2', $html, 1);
            $css = '<style id="msp-legal-nav-css">.msp-legal-utility{background:#f0f5f2;border-bottom:1px solid #d5e4d9;padding:5px 16px}.msp-legal-utility-links,.msp-legal-footer{display:flex;flex-wrap:wrap;gap:9px 18px;justify-content:center}.msp-legal-utility-links a{color:#145936;font-size:12px;text-decoration:none;font-weight:600}.msp-legal-footer{margin-top:10px}.msp-legal-footer a{color:#fff;font-size:12px;text-decoration:underline}.msp-legal-utility-links a:focus-visible,.msp-legal-footer a:focus-visible{outline:2px solid currentColor;outline-offset:2px}@media(max-width:720px){.msp-legal-utility-links{gap:4px 10px}.msp-legal-utility-links a{font-size:11px}}</style>';
            $html = str_replace('</head>', $css . "\n</head>", $html);
        }
        if (is_front_page()) {
            // Preserve JS-powered skip/back-to-top controls while eliminating
            // fragment href values from the pre-approval homepage snapshot.
            $html = preg_replace('~href="#(main|wrapper)"~i', 'href="/" data-msp-scroll-to="$1"', $html);
            $script = '<script id="msp-home-local-scroll">document.addEventListener("click",function(e){var a=e.target.closest("a[data-msp-scroll-to]");if(!a)return;var id=a.getAttribute("data-msp-scroll-to");var el=document.getElementById(id);if(el){e.preventDefault();el.scrollIntoView({behavior:"smooth",block:"start"});if(id==="main"){el.setAttribute("tabindex","-1");el.focus({preventScroll:true});}}});</script>';
            $html = str_replace('</body>', $script . "\n</body>", $html);
        }
        return $html;
    }

    public static function ads_txt_no_cache(array $headers) : array {
        if (isset($_SERVER['REQUEST_URI']) && parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) === '/ads.txt') {
            $headers['Cache-Control'] = 'no-store, no-cache, must-revalidate';
        }
        return $headers;
    }
    public static function ads_txt_404() : void {
        if (!isset($_SERVER['REQUEST_URI']) || parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) !== '/ads.txt') { return; }
        // Only handles WordPress's dynamic route; a physical file or CDN rule must be removed separately.
        global $wp_query;
        if ($wp_query instanceof WP_Query) { $wp_query->set_404(); }
        status_header(404); nocache_headers();
        include get_404_template(); exit;
    }
}
MSP_Adsense_Eligibility_Guard::init();
